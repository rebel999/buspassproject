function validation(){
	var flag=false;
	var userName=form1.userName.value
	var userpasswd=form1.userPwd.value
	if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="* The user Name should not be empty"
			flag=false;
	}else if(userpasswd==""||userpasswd==null){
		document.getElementById('pwdErrMsg').innerHTML="* The Password should not be empty"
			document.getElementById('userErrMsg').innerHTML=""
			flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}