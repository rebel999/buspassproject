package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean isValidateLogin(LoginBean loginBean) {
		
		String sql="select * from adminLogin where username=? and userpassword=?";
		try(PreparedStatement ps=getMySQLDBConnection().prepareStatement(sql);){
			ps.setString(1, loginBean.getUserName());
			ps.setString(2, loginBean.getUserPassword());
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
				return true;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private Connection getMySQLDBConnection() {
		Connection connection=null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
				return connection;
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			return null;
	}

}
