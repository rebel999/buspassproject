package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDao iLoginDao = new LoginDaoImpl();
	@Override
	public boolean isValidateLogin(LoginBean loginBean) {
		if(iLoginDao.isValidateLogin(loginBean)) {
			return true;	
			}
		return false;
	}

}
